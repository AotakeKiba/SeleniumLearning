package Testing1;

import org.testng.annotations.Test;

public class Testing1File {
  @Test
  public void f() {
  }
}
