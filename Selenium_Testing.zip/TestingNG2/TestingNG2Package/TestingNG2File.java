package TestingNG2Package;

import org.testng.annotations.Test;

public class TestingNG2File {
  @Test
  public void f() {
	  System.out.println("launching firefox browser"); 
  }
}
