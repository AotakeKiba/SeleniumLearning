import java.util.*;

public class Main {
	
//==================================================================================
// DFS/BFS
	char [][] grid = {{'1','1','0','0','0'},
					  {'1','1','0','0','0'},
            		  {'0','0','1','0','0'},
            		  {'0','0','0','1','1'}};
	
	public void findAdjacentIslands(char[][] grid, int i, int j, int r, int c){
        // recursion to find island on top, bottom, left, and right
        if(i<0 || i>=r || j<0 || j>=c || grid[i][j] != '1')  return;
        
        grid[i][j] = '0';
        findAdjacentIslands(grid, i-1, j, r, c);
        findAdjacentIslands(grid, i, j+1, r, c);
        findAdjacentIslands(grid, i+1, j, r, c);
        findAdjacentIslands(grid, i, j-1, r, c);
            
    }
	
	public int numIslands(char[][] grid) {
		 int island = 0;
		 int r = grid.length;
	     int c = grid[0].length;
		 
	        for (int i = 0; i<=grid.length-1; i++){
	            for (int j = 0; j<=grid[i].length-1; j++) {
	            	if (grid[i][j] == '1') {
	            		findAdjacentIslands(grid, i, j, r, c);
	            		island++;
	            	}            
	            }	         
	        }	
			return island;
	    }

//==================================================================================
// Palindrome
	int palindrome = 1231;
	 
	public boolean isPalindrome(int x) {
		 String temp = Integer.toString(x);
		 int [] newInt = new int[temp.length()];
		 for (int i = 0; i < temp.length(); i++) {
			 newInt[i] = temp.charAt(i);
		 }
		 
		 int j = newInt.length;
		 
		 for (int i = 0; i < newInt.length-1; i++) {
			 if (newInt[i] != newInt[j-1]) {
				 return false;
			 }
			 j--;
		 }
		 
	     return true;   
	    }

//==================================================================================	
// Rotate 2D Array
	int [][] rotateArray = {{1,2,3},
							{4,5,6},
							{7,8,9}};
	
	public void rotate(int[][] matrix) {
		int n = matrix.length;
        for (int i = 0; i < (n + 1) / 2; i ++) {
            for (int j = 0; j < n / 2; j++) {
                int temp = matrix[n - 1 - j][i];
                matrix[n - 1 - j][i] = matrix[n - 1 - i][n - j - 1];
                matrix[n - 1 - i][n - j - 1] = matrix[j][n - 1 -i];
                matrix[j][n - 1 - i] = matrix[i][j];
                matrix[i][j] = temp;
            }
        }
        for (int i=0; i<matrix.length; i++) {
        	for (int j=0; j<matrix.length; j++) {
        		System.out.print(matrix[i][j]);
        	}
        	System.out.println();
        }
    }

//==================================================================================
// Roman to Integer
	String s = "MCXIII";
	
	public int romanToInt(String s) {
		int length = s.length();
		int total = 0;
		
//		Map<String, Integer> roman = new LinkedHashMap<String, Integer>();
//		roman.put("I", 1);
//		roman.put("V", 5);
//		roman.put("X", 10);
//		roman.put("L", 50);
//		roman.put("C", 100);
//		roman.put("D", 500);
//		roman.put("M", 1000);

		//String [] roman = {"I", "V", "X", "L", "C", "D", "M"};
		//int [] romanInt = {1, 5, 10, 50, 100, 500, 1000};
				
		// first solution (hashmap) ((failed))
//		for (int i = 0; i < length; i++) {
////			System.out.println(roman.keySet().toArray()[i]);
////			System.out.println(roman.keySet().toArray()[i+1]);
//			
//			if (roman.containsKey(s.charAt(i))) {
//				System.out.println("1");
//			}
			
//			if (roman.get(roman.keySet().toArray()[i]) < roman.get(roman.keySet().toArray()[i+1])) {
//				total -= roman.get(roman.keySet().toArray()[i]);
//				System.out.println("1");
//			}
//			else{
//				total += roman.get(roman.keySet().toArray()[i]);
//				System.out.println("0");
//			}
//		}
		
	    // Second solution (brute force) ((failed))
//		for (int i = 0; i < length; i++) {
//			for (int j = 0; j < roman.length; j++) {
//				if (s.substring(i,i+1).equals(roman[j])) {
//					if (i < length-1) {
//						System.out.println(roman[j]);
//						if (s.substring(i+1,i+2).equals(roman[j+1])) {
//							total = total + (romanInt[j+1] - romanInt[j]);
//							i++;
//						}
//						else if (s.substring(i+1,i+2).equals(roman[j+2])) {
//							total = total + (romanInt[j+2] - romanInt[j]);
//							i++;
//						}
//						else {
//							total = total + romanInt[j];
//						}
//					}
//					else {
//						if (!s.substring(i-1,i).equals(roman[j-1]) && !s.substring(i-1,i).equals(roman[j-2])) {
//							total = total + romanInt[j];
//						}
//					}
//				}
//			}
//		}
		
		// Third Solution (simple)
	        for (int i = 0; i < length; i++) {
	            char ch = s.charAt(i);
	            int cur = getValue(ch);
	            if (i < length - 1 && cur < getValue(s.charAt(i + 1))) {
	                total -= cur;
	            } else {
	                total += cur;
	            }
	        }
	        return total;
	    }

    private int getValue(char ch) {
        int ans = 0;
        switch (ch) {
            case 'I':
                ans = 1;
                break;

            case 'V':
                ans = 5;
                break;

            case 'X':
                ans = 10;
                break;

            case 'L':
                ans = 50;
                break;

            case 'C':
                ans = 100;
                break;

            case 'D':
                ans = 500;
                break;

            case 'M':
                ans = 1000;
                break;

            default:
                break;
        }
		return ans;
		
    }
	
//==================================================================================
// Find original Array from doubled array
    int[] changed = {1,3,4,2,6,8};
    
    public int[] findOriginalArray(int[] changed) {
     	ArrayList<Integer> original = new ArrayList<Integer>();
     	
     	Arrays.sort(changed);
     	
     	if (changed.length % 2 == 0) {
     		for (int i = 0; i < changed.length; i++) {
            	for (int j = i; j < changed.length-1; j++) {
        			if (changed[i]*2 == changed[j+1]) {
            			original.add(changed[i]);
            			changed[j+1] = -1;
            			break;
            		}
            	}
            }
     	}
        
        if (original.size()*2 != changed.length) {
        	int size = original.size();  
        	while(size!=0) {
        		original.remove(0);
        		size--;
        	}
        }
        
        int[] original2 = new int [original.size()];
        if (original.size()!=0) {
        	for (int i = 0; i < original.size(); i++) {
        		original2[i] = original.get(i);
        		System.out.println(original2[i]);
        	}
        }
    	
        
    	return original2;
    }

//==================================================================================
//Maximum length of repeated subarray
    int[] num1 = {1,2,3,2,1};
    int[] num2 = {3,2,1,4,7};
    
    public int findLength(int[] nums1, int[] nums2) {
        int size = 0;
        int temp = 0;
        int flag = 0;
        
        for (int i = 0; i < nums1.length; i++) {
        	for (int j = 0; j< nums2.length; j++) {
        		if (nums1[i] == nums2[j]) {
        			
        		}
        	}
        }
        
        
        return size;
    }

//==================================================================================    
//Pangram
    String sentence = "asd";
    
    public boolean checkIfPangram(String sentence) {
    	String[] alphabet = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
    	int[] status = new int[alphabet.length];
    	
    	String[] container = new String[sentence.length()];
    	
    	for (int i = 0; i< sentence.length(); i++) {
    		container[i] = sentence.substring(i, i+1);
    	}
    	
    	for (int i = 0; i < container.length; i++) {
    		for (int j = 0; j < alphabet.length; j++) {
    			if (container[i].equals(alphabet[j])) {
    				status[j]++;
    				continue;
    			} 
    		}
    	}
    	
    	for (int i = 0; i < status.length; i++) {
    		if (status[i] == 0) {
    			return false;
    		}
    	}
    	return true;
    }
    
//==================================================================================
//Check Capital
    String word = "Aku Mau";
    public boolean detectCapitalUse(String word) {
    	int[] flag = new int[word.length()];
    	int flag2 = 0;
    	for (int i = 0; i < word.length(); i++) {
    		if (Character.isUpperCase(word.charAt(i))) {
    			flag[i] = 1;
    			flag2++;
    			System.out.println(flag[i]);
    		}
    	}
    	
    	if (flag2 == 0 || word.length() == flag2) {
    		System.out.println("1");
    		return true;
    	}
    	else if (word.length() - flag2 == word.length()-1) {
    		System.out.println("2");
    		if (flag[0] == 1) {
    			System.out.println("3");
    			return true;
    		}
    	}
    	return false;
    }

//==================================================================================
//Minimum Round (solution from leetcode)
    int[] tasks = new int [] {2,2,3,3,2,4,4,4,4,4};
    public int minimumRounds(int[] tasks) {
        Map<Integer, Integer> freq = new HashMap();
        // Store the frequencies in the map.
        for (int task : tasks) {
            freq.put(task, freq.getOrDefault(task, 0) + 1);
        }

        int minimumRounds = 0;
        // Iterate over the task's frequencies.
        for (int count : freq.values()) {
            // If the frequency is 1, it's not possible to complete tasks.
            if (count == 1) {
                return - 1;
            }

            if (count % 3 == 0) {
                // Group all the task in triplets.
                minimumRounds += count / 3;
            } else {
                // If count % 3 = 1; (count / 3 - 1) groups of triplets and 2 pairs.
                // If count % 3 = 2; (count / 3) groups of triplets and 1 pair.
                minimumRounds += count / 3 + 1;
            }
        }

        return minimumRounds;
    }

//==================================================================================
//Maxmum icecream that can be bought
    
    int[] cost = new int [] {1,3,2,4,1};
    int coins = 10;
    public int maxIceCream(int[] costs, int coins) {
        int bought = 0;
        Arrays.sort(costs);
        
        for (int i = 0; i < costs.length; i++) {
        	if (coins - costs[i] < 0) {
        		break;
        	}
        	coins = coins - costs[i];
        	bought++;
        }
        
        return bought;
    }
 
//==================================================================================
//N-th Tribonacci Number
    int num = 25;
    public int tribonacci(int n) {
    	int [] A = new int[n+1];
    	if (n == 0 || n == 1) {
    		return n;
    	}
    	if (n == 2) {
    		return 1;
    	}
    	
    	A[0] = 0;
    	A[1] = 1;
    	A[2] = 1;
    	
    	for (int i = 3; i <= n; i++) {
    		A[i] = A[i-1] + A[i-2] + A[i-3];
    	}
    	
        return A[n];
    }

//==================================================================================
//Greatest Common Divisor of Strings
    
    String str1 = "ABCABC";
    String str2 = "ABC";
    
    public int gcd (int x, int y) {
    	if (y == 0) {
    		return x;
    	}else {
    		return gcd(y, x % y);
    	}
    }
    
    public String gcdOfStrings(String str1, String str2) {
    	if (!(str1 + str2).equals(str2 + str1)) {
    		return "";
    	}
        
    	int gcdLength = gcd(str1.length(), str2.length());
    	return str1.substring(0, gcdLength);
    }
    
//==================================================================================
//Shuffle the Array
    int nums[] = {2,5,1,3,4,7};
    int n = 3;
    
    public int[] shuffle(int[] nums, int n) {
    	int temp [] = new int[nums.length];
    	int start = 0;
    	
    	if (nums.length / n != 2) {
    		return temp;
    	}
    	
    	for (int i = 0; i < temp.length; i++) {
    		if (i%2 == 0) {
    			temp[i] = nums[start];
    			start++;
    		}else {
    			temp[i] = nums[n];
    			n++;
    		}
    	}
    	
    	for (int i : temp) {
			System.out.println(i);
		}
    	
        return temp;
    }

//==================================================================================    
//Count Odd Numbers in an Interval Range    
    int low = 3;
    int high = 7;
    
    public int countOdds(int low, int high) {   	
    	int count = 0;
    	
    	if (low%2 == 0) {
    		low ++;
    	}
    	
    	if (low > high) {
    		return count;
    	}
    	
    	return ((high - low)/2)+1;
    }
    
//==================================================================================    
//Add Binary
    String a = "11";
    String b = "1";
    
    public String addBinary(String a, String b) {
    	StringBuilder res = new StringBuilder();
        int i = a.length() - 1;
        int j = b.length() - 1;
        int carry = 0;
        while(i >= 0 || j >= 0){
            int sum = carry;
            if(i >= 0) sum += a.charAt(i--) - '0';
            if(j >= 0) sum += b.charAt(j--) - '0';
            carry = sum > 1 ? 1 : 0;
            res.append(sum % 2);
        }
        if(carry != 0) res.append(carry);
        return res.reverse().toString();
    }

//==================================================================================    
//Add to Array-Form of Integer
    int[] Array_form_of_integer = {1,2,6,6};
    int k = 34;
    
    public List<Integer> addToArrayForm(int[] num, int k) {
    	List<Integer> res = new LinkedList<>();
	    for (int i = num.length - 1; i >= 0; --i) {
	        res.add(0, (num[i] + k) % 10);
	        k = (num[i] + k) / 10;
	    }
	    while (k > 0) {
	        res.add(0, k % 10);
	        k /= 10;
	    }
	    return res;
    }

//==================================================================================    
//Search Insert Position
    int search_insert_position [] = new int[] {1,3,5,6};
    int target = 7;
    
    public int searchInsert(int[] nums, int target) {
        for (int i = 0; i < nums.length; i++) {
        	if (nums[i] == target || nums[i] > target) {
        		return i;
        	}
        }
        
        return nums.length;
    }
    
//==================================================================================    
//Search Insert Position
    int single_non_duplicate [] = new int [] {7,7,10,11,11,12,12};
    
    public int singleNonDuplicate(int[] nums) {
    	// o(n) time complexity
//    	for (int i = 0; i < nums.length; i += 2) {
//    		if (i == nums.length-1) {
//    			return nums[i];
//    		}
//    		if (nums[i] != nums[i+1]) {
//    			return nums[i];
//    		}
//    	}
//    	return 0;
    	
    	// o(log n) time complexity
    	int l = 0;
    	int r = nums.length-1;
    	
    	if (nums.length == 1){
            return nums[0];
        }
    	
    	if (nums[r] != nums[r-1]) {
    		return nums[r];
    	}
    	
    	if (nums[l] != nums[l+1]) {
    		return nums[l];
    	}
    	
    	while (l <= r) {
    		int m = l + (r-l)/2;
//    		System.out.println("int m = " + m);
//    		System.out.println("int l = " + l);
//    		System.out.println("int r = " + r);
//    		System.out.println(nums[m]);
    		if (nums[m] != nums[m-1] && nums[m] != nums[m+1]) {
    			return nums[m];
    		}
    		 else if ((nums[m] == nums[m + 1] && m % 2 == 0) || (nums[m] == nums[m - 1] && m % 2 != 0))
                 l = m + 1;
             else
                 r = m - 1;
         }
    	
    	return nums[l];
    }
  
    
    public void main() {
		//DFS
		//System.out.println(numIslands(grid));
		
		//Palindrome
		//System.out.println(isPalindrome(palindrome));
		
		//Rotate 2D Array
		//rotate(rotateArray);
		
		//Roman to Integer
		//System.out.println(romanToInt(s));
		
		//Find original Array from doubled array
		//System.out.println(findOriginalArray(changed));
	
    	//Maximum length of repeated subarray
    	//System.out.println((findLength(num1, num2)));
    	
    	//Pangram
    	//System.out.println(checkIfPangram(sentence));
    	
    	//check capital
    	//System.out.println(detectCapitalUse(word));
    	
    	//minimum round
    	//System.out.println(minimumRounds(tasks));
    	
    	//Maxmum icecream that can be bought
    	//System.out.println(maxIceCream(cost,coins));
    	
    	//N-th Tribonacci Number
    	//System.out.println(tribonacci(num));
    	
    	//Greatest Common Divisor of Strings
    	//System.out.println(gcdOfStrings(str1, str2));
    	
    	//Shuffle the Array
    	//System.out.println(shuffle(nums, n));
    	
    	//Count Odd Numbers in an Interval Range 
    	//System.out.println(countOdds(low, high));
    	
    	//Add Binary
    	//System.out.println(addBinary(a, b));
    	
    	//Add to Array-Form of Integer
    	//System.out.println(addToArrayForm(Array_form_of_integer, k));
    	
    	//Search Insert Position
    	//System.out.println(searchInsert(search_insert_position, target));
    	
    	//Search Insert Position
    	System.out.println(singleNonDuplicate(single_non_duplicate));
    }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main main = new Main();
		main.main();
	}	
}
